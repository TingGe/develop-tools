// ==UserScript==
// @name         解决奇艺解析问题
// @namespace    http://tampermonkey.net/
// @version      666.999.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @include         /^http:\/\/www\.iqiyi\.com\/(v|a|w)_(.*)/
// @grant             天地无用
// @run-at           document-start
// ==/UserScript==
