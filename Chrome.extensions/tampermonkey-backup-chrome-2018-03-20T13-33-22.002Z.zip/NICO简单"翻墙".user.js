// ==UserScript==
// @name            NICO简单"翻墙"
// @namespace       http://weibo.com/myimagination
// @author          @MyImagination
// @version			1.1.0
// @homepageURL     https://greasyfork.org/users/2805-myimagination
// @description     【标准版】点击搜索页面的图片链接即可新开一个页面免翻墙浏览
// @include         http://*.nicovideo.jp/tag/*
// @include         http://*.nicovideo.jp/search/*
// @include         http://www.nicovideo.jp/my/mylist*
// @include         http://ex.nicovideo.jp/*
// @include         http://www.nicovideo.jp/video_top*
// @include         http://www.nicovideo.jp/mylist/*
// @include         http://com.nicovideo.jp/video/*
// @run-at          document-end
// ==/UserScript==
if (window.location.href.indexOf('mylist') > 0) {
  var j = jQuery.noConflict();
  if (window.location.href.indexOf('/my/') > 0) {
    var title = j('#myContBody');
    title.bind('DOMNodeInserted', function (e) {
      var ti = j(e.target).find('.thumbContainer a').last();
      if (ti.attr('href').indexOf('vocalover') <= 0) {
        //ti.attr('href', 'http://nico.vocalover.com/' + ti.attr('href').substr(ti.attr('href').indexOf('watch/') + 6));
        ti.attr('href', 'http://nico.vocalover.com/' + nico_list(ti.attr('href')));
      }
    });
  } else {
    var title = j('#SYS_box_mylist_body');
    title.bind('DOMNodeInserted', function (e) {
      var ti = j(e.target).find('.img_std96').last().closest('a');
      if (ti.attr('href').indexOf('vocalover') <= 0) {
       // ti.attr('href', 'http://nico.vocalover.com/' + ti.attr('href').substr(ti.attr('href').indexOf('watch/') + 6));
        ti.attr('href', 'http://nico.vocalover.com/' + nico_list(ti.attr('href')));
      }
    });
  }
} else if (window.location.href.indexOf('video/') > 0) {
  var obj_a = nico_getByClass_('video_img_M');
  for (var j = 0; j < obj_a.length; j++) {
    var vr = obj_a[j].parentNode.href.substr(obj_a[j].parentNode.href.indexOf('watch/') + 6);
    obj_a[j].parentNode.href = 'http://nico.vocalover.com/' + vr;
  }
} else {
  $('a').each(function () {
    if ($(this).children().is('img')) {
      if ($(this).attr('href').indexOf('watch') > 0 && $(this).attr('href').indexOf('live') < 0) {
        //$(this).attr('href', 'http://nico.vocalover.com/' + $(this).attr('href').substr($(this).attr('href').indexOf('watch/') + 6));
        $(this).attr('href', 'http://nico.vocalover.com/' + nico_list($(this).attr('href')));
      }
    }
  })
}
function nico_getByClass_(sClass) {
  var aResult = new Array();
  var aEle = document.getElementsByTagName('img');
  for (var i = 0; i < aEle.length; i++) {
    if (aEle[i].className == sClass) {
      aResult.push(aEle[i]);
    }
  }
  return aResult;
}
function nico_list(nls) {
  if (nls.indexOf('?') <= 0) {
    return nls.substr(nls.indexOf('watch/') + 6);
  } else {
    return nls.substr(nls.indexOf('watch/') + 6, nls.indexOf('?') - 7);
  } 

}